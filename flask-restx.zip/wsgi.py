import platform
from manage import app

if __name__ == "__main__":
    # Check the System Type before to decide to bind
    # If the system is a Linux machine -:)
    if platform.system() == "Linux":
        app.run(app, host='0.0.0.0', port=5000, debug=app.config.get(
            'DEBUG', False), use_reloader=app.config.get('USE_RELOADER', False))
    # If the system is a windows /!\ Change  /!\ the   /!\ Port
    elif platform.system() == "Windows":
        app.run(app, host='0.0.0.0', port=5000, debug=app.config.get(
            'DEBUG', False), use_reloader=app.config.get('USE_RELOADER', False))