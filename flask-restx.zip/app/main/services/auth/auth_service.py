
from flask import request
from app.main.models.users.user_model import User
from app.main.utils.custom_exception import CustomException
from app.main.utils.response_formatter import ResponseFormater


def login_user():
    username = request.json.get('username', None)
    password = request.json.get('password', None)

    if not username:
        return CustomException.bad_request('Field username is Required')
    if not password:
        return CustomException.bad_request('Field password is Required')
    
    user = User.query.filter_by(username=username).first()

    if not user or user and not user.check_password(password):
        return CustomException.unauthorize('Please check your credentials.')
    
    auth_token = User.encode_auth_token(user.id)
    data = {
        "auth_token": auth_token,
        "token_type": "Bearer"
    }
    return ResponseFormater.format(ResponseFormater.get_pagination(), data, 202, "Youre already Login.")
