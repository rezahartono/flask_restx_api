import json
import uuid
import datetime

from flask import request

from app.main import db
from app.main.models.users.user_model import User
from typing import Dict, Tuple
from app.main.utils.jwt_util import get_jwt_error_message, verify_jwt
from app.main.utils.response_formatter import ResponseFormater
from app.main.utils.custom_exception import CustomException


def save_user(data: Dict[str, str], public_id: str = None) -> Dict[str, str]:
    try:
        if not public_id:
            user = User.query.filter_by(email=data['email']).first()
            if not user:
                new_user = User(
                    public_id=str(uuid.uuid4()),
                    name=data['name'],
                    email=data['email'],
                    username=data['username'],
                    password=data['password'],
                    created_at=datetime.datetime.utcnow(),
                    updated_at=datetime.datetime.utcnow()
                )
                save_changes(new_user)
                result = generate_token(new_user)
                return ResponseFormater.format(ResponseFormater.get_pagination(), result, 201, "User has been registered.")
            else:
                return CustomException.conflict('User already exists. Please Log in.')
        else:
            user = User.query.filter_by(public_id=public_id).first()
            if data['name']:
                user.name = data['name'],
            if data['email']:
                user.email = data['email'],
            if data['username']:
                user.username = data['username'],
            if data['password']:
                user.password = data['password'],
            user.updated_at = datetime.datetime.utcnow()
            save_changes()
            return ResponseFormater.format(ResponseFormater.get_pagination(), None, 202, 'Data has been updated.')
    except Exception as e:
        return CustomException.internal_server_error()


def get_all_users():
    try:
        if(verify_jwt()):
            page = request.args.get('page', 1, type=int)
            search = request.args.get('search', None)
            if search:
                users = User.query.filter(User.name.like(
                    '%'+search+'%')).paginate(page=page, per_page=10, error_out=False)
            else:
                users = User.query.paginate(
                    page=page, per_page=10, error_out=False)
            data = [user.to_json() for user in users]
            return ResponseFormater.format(ResponseFormater.get_pagination(users), data, 200, "Get data success.")
        else:
            return CustomException.forbidden(get_jwt_error_message())

    except Exception as e:
        print(e)
        return CustomException.internal_server_error()


def get_user(public_id):
    try:
        data = User.query.filter_by(public_id=public_id).first()
        if data:
            return ResponseFormater.format(ResponseFormater.get_pagination(), data.to_json(), 200, "Get data success.")
        else:
            return CustomException.not_found()
    except Exception:
        return CustomException.internal_server_error()


def delete_user(public_id):
    try:
        data = User.query.filter_by(public_id=public_id).first()
        if data:
            db.session.delete(data)
            save_changes()
            return ResponseFormater.format(ResponseFormater.get_pagination(), None, 200, "Delete data success.")
        else:
            return CustomException.not_found()
    except Exception:
        return CustomException.internal_server_error()


def generate_token(user: User) -> Dict[str, str]:
    try:
        # generate the auth token
        auth_token = User.encode_auth_token(user.id)
        data = {
            "auth_token": auth_token,
            "token_type": "Bearer"
        }
        return data
    except Exception as e:
        return CustomException.internal_server_error('Some error occurred. Please try again.')


def save_changes(data: User = None) -> None:
    if data:
        db.session.add(data)
    db.session.commit()
