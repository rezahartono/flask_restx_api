
import datetime
from typing import Union

import jwt
from app.main import db, flask_bcrypt
from app.main.config import PASSWORD_SALT, key
from app.main.models.auth.blacklist_model import BlacklistToken
from app.main.utils.custom_exception import CustomException


class User(db.Model):
    # table name
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    username = db.Column(db.String(150), unique=True, nullable=False)
    public_id = db.Column(db.String(60), unique=True, nullable=False)
    password_hash = db.Column(db.String(150), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False)
    updated_at = db.Column(db.DateTime, nullable=False)

    @property
    def password(self):
        raise AttributeError('password: write-only field')
    
    @password.setter
    def password(self, password:str):
        self.password_hash = flask_bcrypt.generate_password_hash(str(password)+PASSWORD_SALT).decode('utf-8')

    def check_password(self, password: str) -> bool:
        return flask_bcrypt.check_password_hash(self.password_hash, str(password)+PASSWORD_SALT)

    @staticmethod
    def encode_auth_token(user_id: int) -> str:
        """
        Generates the Auth Token
        :return: string
        """
        try:
            payload = {
                'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1, seconds=5),
                'iat': datetime.datetime.utcnow(),
                'sub': user_id
            }
            return jwt.encode(
                payload,
                key,
                algorithm='HS256'
            )
        except Exception as e:
            return e

    @staticmethod
    def decode_auth_token(auth_token: str) -> Union[str, int]:
        """
        Decodes the auth token
        :param auth_token:
        :return: integer|string
        """
        try:
            payload = jwt.decode(auth_token, key, algorithms=["HS256"])
            is_blacklisted_token = BlacklistToken.check_blacklist(auth_token)
            if is_blacklisted_token:
                return CustomException.forbidden('Token blacklisted. Please log in again.')
            else:
                return payload['sub']
        except jwt.ExpiredSignatureError:
            return CustomException.forbidden('Signature expired. Please log in again.')
        except jwt.InvalidTokenError:
            return CustomException.forbidden('Invalid token. Please log in again.')

    def __repr__(self):
        return "<User '{}'>".format(self.username)
    
    def to_json(self):
        return {
            "public_id": self.public_id,
            "name": self.name,
            "email": self.email,
            "username": self.username,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            "updated_at": self.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
        }
