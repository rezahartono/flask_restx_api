from flask import request
from flask_restx import Resource
from app.main.services.users.users_service import delete_user, get_all_users, get_user, save_user
from app.main.utils.dto import custom_response_model, UserDto

api=UserDto.api
create_model=UserDto.create_user_model

@api.route('/')
class UserList(Resource):
    @api.doc(responses={
        200: 'OK',
        401: 'Unauthorize',
        500: 'Internal Server Error',
    })
    @api.marshal_with(custom_response_model(api), code=200)
    def get(self):
        return get_all_users()
    
@api.route('/create')
class CreateUser(Resource):
    @api.doc(responses={
        201: 'Created',
        409: 'Conflict',
        401: 'Unauthorize',
        500: 'Internal Server Error',
    })
    @api.marshal_with(custom_response_model(api), code=201)
    @api.expect(create_model, validate=True,)
    def post(self):
        return save_user(request.json) 
    
@api.route('/<public_id>')
class UserData(Resource):
    @api.doc(responses={
        200: 'OK',
        500: 'Internal Server Error',
        404: 'Not Found',
    })
    @api.marshal_with(custom_response_model(api), code=200)
    def get(self, public_id):
        return get_user(public_id)
    
    @api.doc(responses={
        202: 'Accepted',
        500: 'Internal Server Error',
        404: 'Not Found',
    })
    @api.marshal_with(custom_response_model(api), code=202)
    @api.expect(create_model, validate=True,)
    def put(self, public_id):
        return save_user(request.json, public_id)
    
    @api.doc(responses={
        202: 'Accepted',
        500: 'Internal Server Error',
        404: 'Not Found',
    })
    @api.marshal_with(custom_response_model(api), code=202)
    def delete(self, public_id):
        return delete_user(public_id)
