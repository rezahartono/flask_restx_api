from flask_restx import Resource
from app.main.utils.dto import AuthDto, custom_response_model
from app.main.utils.custom_exception import CustomException
from app.main.services.auth.auth_service import login_user

api = AuthDto.api
login_model = AuthDto.login_model

@api.route('/login')
class SignIn(Resource):
    @api.doc(responses={
        200: "OK",
        401: "Unauthorize",
        500: "Internal Server Error"
    })
    @api.expect(login_model)
    @api.marshal_with(custom_response_model(api), 200)
    def post(self):
        return login_user()