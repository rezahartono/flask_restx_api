from http import HTTPStatus
import math

from flask import request


class ResponseFormater:
    @staticmethod
    def format(pagination=None, data=None, status_code=200, message=None):
        return {
            "metadata": ResponseFormater.metadata(message, status_code),
            "pagination": pagination,
            "data": data,
        }, status_code

    @staticmethod
    def metadata(message=None, status_code=200):
        return {
            "path": ResponseFormater.get_context_path(),
            "status": ResponseFormater.get_status_name(status_code),
            "status_code": status_code,
            "message": message
        }

    @staticmethod
    def get_context_path():
        url = request.url.replace(request.root_url, "/")
        if "?" in url:
            newUrl = url.split("?")[0]
            return newUrl.rstrip('/')
        else:
            return url.rstrip('/')

    @staticmethod
    def get_status_name(status_code=200):
        return HTTPStatus(status_code).phrase

    @staticmethod
    def get_pagination(data=None):
        if data is not None:
            current_page = data.page
            total_page = math.ceil(data.total / data.per_page) or 1
            current_item = len(data.items)
            total_item = data.total
        else:
            current_page = 1
            total_page = 1
            current_item = 1
            total_item = 1
        return {
            "current_page": current_page,
            "total_page": total_page,
            "current_item": current_item,
            "total_item": total_item,
        }
