from flask_restx import Namespace, fields

def custom_response_model(api, status_code=None):
    return api.model('response', {
        'metadata': fields.Nested(api.model('Metadata', {
            'path': fields.String(required=True, description='API path'),
            'status': fields.String(required=True, description='Status'),
            'status_code': fields.Integer(required=True, description='Status code'),
            'message': fields.String(required=True, description='Response message')
        })),
        'pagination': fields.Nested(api.model('Pagination', {
            'current_page': fields.Integer(required=True, description='Current page'),
            'total_page': fields.Integer(required=True, description='Total pages'),
            'current_item': fields.Integer(required=True, description='Current item count'),
            'total_item': fields.Integer(required=True, description='Total item count')
        })),
        'data': fields.Raw(description='Response data')
    })

class UserDto:
    api = Namespace('users', description='Restfull API for users')
    create_user_model = api.model('user', {
        'name':fields.String(required=True, description='name of user'),
        'email': fields.String(required=True, description='user email address'),
        'username': fields.String(required=True, description='user username'),
        'password': fields.String(required=True, description='user password'),
    })

class AuthDto:
    api = Namespace('auth', description="Restfull API for Authentication", path='/')
    login_model = api.model('login', {
        'username': fields.String(required=True, description='user username'),
        'password': fields.String(required=True, description='user password'),
    })