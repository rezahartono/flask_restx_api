from flask import request
import jwt
from app.main.config import key
from app.main.models.auth.blacklist_model import BlacklistToken
from app.main.utils.custom_exception import CustomException


def verify_jwt():
    raw_auth_token = request.headers.get('Authorization', None)
    is_verify = True
    if not raw_auth_token:
        is_verify = False
    else:
        try:
            auth_token = str(raw_auth_token).split(' ')[1]
            jwt.decode(auth_token, key, algorithms=["HS256"])
            is_blacklisted_token = BlacklistToken.check_blacklist(auth_token)
            if is_blacklisted_token:
                is_verify = False
        except jwt.ExpiredSignatureError:
            is_verify = False
        except jwt.InvalidTokenError as e:
            is_verify = False
    return is_verify


def get_jwt_error_message():
    raw_auth_token = request.headers.get('Authorization', None)
    if not raw_auth_token:
        return 'Please insert Authorization.'
    else:
        try:
            auth_token = str(raw_auth_token).split(' ')[1]
            print(auth_token)
            jwt.decode(auth_token, key, algorithms=["HS256"])
            is_blacklisted_token = BlacklistToken.check_blacklist(auth_token)
            if is_blacklisted_token:
                return 'Token blacklisted. Please log in again.'
        except jwt.ExpiredSignatureError:
            return 'Signature expired. Please log in again.'
        except jwt.InvalidTokenError:
            return 'Invalid token. Please log in again.'
