
from app.main.utils.response_formatter import ResponseFormater


class CustomException:
    @staticmethod
    def unauthorize(message: str = None):
        return ResponseFormater.format(ResponseFormater.get_pagination(), None, 401, message or "Unauthorize")

    @staticmethod
    def not_found(message: str = None):
        return ResponseFormater.format(ResponseFormater.get_pagination(), None, 404, message or "Not Found")

    @staticmethod
    def conflict(message: str = None):
        return ResponseFormater.format(ResponseFormater.get_pagination(), None, 409, message or "Request Conflict")

    @staticmethod
    def internal_server_error(message: str = None):
        return ResponseFormater.format(ResponseFormater.get_pagination(), None, 500, message or "Internal Server Error")

    @staticmethod
    def forbidden(message: str = None):
        return ResponseFormater.format(ResponseFormater.get_pagination(), None, 403, message or "Forbidden")

    @staticmethod
    def bad_request(message: str = None):
        return ResponseFormater.format(ResponseFormater.get_pagination(), None, 400, message or "Bad Request")
